import logo from './logo.svg';
import './App.css';
import FAjaxGet from './FAjaxGet';

function App() {
  return (
    <div className="App">
     <FAjaxGet></FAjaxGet>
    </div>
  );
}

export default App;
