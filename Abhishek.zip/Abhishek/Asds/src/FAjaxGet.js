import axios from "axios"
import { useState } from "react"
export default function FAjaxGet(){

    let [arr, setarr] = useState([]);

    function handler(){
        let promise = axios.get("http://localhost:5220/products")
        promise.then((response) => {
            
           let arr = (response.data)
            setarr(arr)
            console.log(arr)
        })
    }



    return(
        <>
        <h4>Ajax Get Data From Database</h4>
        <div>
            <input type = "button" value = "Get" onClick={handler}/>
        </div>
        <div>
            {arr.map((item) => {
                return (
                    <>     
                    <p>{item.pid}</p>
                    <p>{item.pname}</p>
                    </>
                )
            })}
        </div>
        </>
    )
}