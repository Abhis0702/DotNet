namespace BLL;
using DAL.Connected;
using BOL;
public class CatalogueManager{
    public List<Product> GetAllProducts(){
        List<Product> allproducts = new List<Product>();
        allproducts = DBManager.GetAllProducts();
        return allproducts;
    }
}