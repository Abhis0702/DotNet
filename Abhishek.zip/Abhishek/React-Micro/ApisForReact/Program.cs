using BLL;
using BOL;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!");
app.MapGet("/Products", () => {
    CatalogueManager mg = new CatalogueManager();
    List<Product> list = mg.GetAllProducts();
    return list;
});

app.Run();
