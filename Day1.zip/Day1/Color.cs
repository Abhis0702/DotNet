namespace Graphics;
public struct Color{
    public int red;
    public int green;
    public int blue;
    public Color(int r, int g , int b){
        this.red=r;
        this.blue=b;
        this.green=g;
    }
}