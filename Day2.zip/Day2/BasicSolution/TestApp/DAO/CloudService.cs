using Repo;

namespace DAO;
public class CloudService : IDataService
{
    public bool Create()
    {
        bool status=false;
        //
       return status;
    }

    public bool Delete()
    {
          bool status=false;
        //
       return status;
    }

    public bool Read()
    {  bool status=false;
        //
       return status;
    }

    public bool Update()
    { bool status=false;
        //
       return status;
        
    }
}