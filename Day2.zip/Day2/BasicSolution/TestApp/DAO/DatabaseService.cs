using Repo;

namespace DAO;
public class DatabaseService : IDataService
{
    public bool Create()
    {
        bool status=false;
        //create data in database;
        return status;
         
    }

    public bool Delete()
    {
          bool status=false;
        //create data in database;
        return status;
    }

    public bool Read()
    {  bool status=false;
        //Read data from database;
        return status;
         
    }

    public bool Update()
    {
          bool status=false;
        //update data in database;
        return status;
    }
}
