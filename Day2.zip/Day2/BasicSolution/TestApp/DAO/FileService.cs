using Repo;

namespace DAO{
    public class FileSerive : IDataService
    {
        public bool Create()
        {
            bool status=false;
            //create data inside file
            return status;
            
        }

        public bool Delete()
        {  bool status=false;
            //delte data inside file
            return status;
            
             
        }

        public bool Read()
        {
              bool status=false;
            //read data inside file
            return status;
            
        }

        public bool Update()
        {  bool status=false;
            //update data inside file
            return status;
            
           
        }
    }
}