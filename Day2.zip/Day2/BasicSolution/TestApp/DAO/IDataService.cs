namespace Repo;
public interface IDataService{
    bool Create();
    bool Read();
    bool Update();
    bool Delete();

}