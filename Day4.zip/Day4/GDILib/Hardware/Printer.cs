namespace Hardware;

public interface IPrinter{
    void Print();
    
}