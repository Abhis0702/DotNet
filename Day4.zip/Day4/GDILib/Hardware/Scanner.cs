namespace Hardware;
public interface IScanner{

    public void Scan();
}