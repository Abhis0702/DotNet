
namespace Notification;
public delegate void NotificationOperation(string to, string content);