namespace Taxation;
public delegate  void TaxOperation (float amount);