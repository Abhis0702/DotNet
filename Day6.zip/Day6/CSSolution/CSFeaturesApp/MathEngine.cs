namespace Mathematics;
public sealed class MathEngine{

    public int Addition(int op1, int op2){
        return op1+ op2;
    }

    public int Subtraction(int op1, int op2){
        return op1+ op2;
    }
    
}