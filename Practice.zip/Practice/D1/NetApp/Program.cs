﻿using P1;
using Graphic;

Colors c1 = new Colors(250,0,0);
Person p = new Person();
Person p1 = new Person(2,"Ayush", "Gupta");
Console.WriteLine(p);
Console.WriteLine(p1);
Console.WriteLine(c1);
Console.WriteLine("Hello, World!");