namespace emp;
public sealed class SalesEmployeee:Employee{

    private int 
}
