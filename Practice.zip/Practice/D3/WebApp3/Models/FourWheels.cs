namespace Car;
public class FourWheels{
    public string prodname{get;set;}
    public string prodcompany{get;set;}
    public string prodengine{get;set;}
    public int prodcost{get;set;}
    public int quantity{get;set;}
    public string imageurl{get;set;}
}

