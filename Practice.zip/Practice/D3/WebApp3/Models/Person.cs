namespace Individual;
public class Person{
    public string firstName{get;set;}
    public string lastName{get;set;}
}