namespace Hardware;
public interface IPrinter{
    public void Print();
}