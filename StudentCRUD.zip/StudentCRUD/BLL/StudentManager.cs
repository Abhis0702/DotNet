namespace BLL;
using BOL;
using DAL.Connected;
public class StudentManager{
    public List<Student> GetAll(){
        List<Student> stud = DBManager.GetAll();
        return stud;
    }
    public void Register(int id, string name, int rollno){
        DBManager.Register(id, name, rollno);
    }
    public void Update(int id, string name){
        DBManager.Update(id, name);
    }
     public void Delete(int id){
        DBManager.Delete(id);
    }
}