namespace BOL;

public class Student{

    public int id{get; set;}

    public string name{get; set;}

    public int rollno{get; set;}

    public Student(int id, string name, int rollno){

        this.id = id;
        this.name = name;
        this.rollno = rollno;

    }
}