using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StudentCRUD.Models;
using BLL;
using DAL.Connected;
using BOL;

namespace StudentCRUD.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        StudentManager sdm = new StudentManager();
        List<Student> stud = sdm.GetAll();
        ViewData["allstudents"] = stud;
        return View();
    }
    [HttpGet]
    public IActionResult Register(){
        return View();
    }
    [HttpPost]
    public IActionResult Register(int id, string name, int rollno){
        StudentManager sdm = new StudentManager();
        sdm.Register(id, name, rollno);
        return View();
    }
     [HttpGet]
    public IActionResult Update(){
        return View();
    }
    [HttpPost]
    public IActionResult Update(int id, string name){
        StudentManager sdm = new StudentManager();
        sdm.Update(id, name);
        return View();
    }
     [HttpGet]
    public IActionResult Delete(){
        return View();
    }
    [HttpPost]
    public IActionResult Delete(int id){
        StudentManager sdm = new StudentManager();
        sdm.Delete(id);
        return View();
    }
}
