namespace DAL.Connected;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    public static string constring = @"server=192.168.10.150;port=3306;user=dac31;password=welcome;database=dac31";
    public static List<Student> GetAll(){
        List<Student> stud = new List<Student>();
        MySqlConnection conn = new MySqlConnection();
        conn.ConnectionString = constring;
        string query = "select * from student2";
        MySqlCommand command = new MySqlCommand(query, conn);
        try{
            conn.Open();
            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read()){
                int id = int.Parse(reader["id"].ToString());
                string name = reader["name"].ToString();
                int rollno = int.Parse(reader["rollno"].ToString());
                stud.Add(new Student(id, name, rollno));
            }
            reader.Close();
        }catch(Exception e){
            Console.WriteLine(e.Message);
        }
        finally{
            conn.Close();
        }
        return stud;

    }
    public static void Register(int id, string name, int rollno){
        MySqlConnection conn = new MySqlConnection();
        conn.ConnectionString = constring;
        string query = "insert into student2 values(@id, @name, @rollno)";
        MySqlCommand command = new MySqlCommand(query, conn);
        command.Parameters.AddWithValue("@id",id);
        command.Parameters.AddWithValue("@name",name);
        command.Parameters.AddWithValue("@rollno",rollno);
        conn.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Student Registered Successfully");
        }else {
            Console.WriteLine("Not Registered");
        }
    }
    public static void Update(int id, string name){
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = constring;
        string query = "update student2 set name = @name where id = @id";
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", id);
        command.Parameters.AddWithValue("@name",name);
        connection.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Student Updated Successfully");
        }else {
            Console.WriteLine("Student Not Updated");
        }
        connection.Close();

    }
    public static void Delete(int id){
        MySqlConnection conn = new MySqlConnection();
        conn.ConnectionString = constring;
        string query = "delete from student2 where id = @id";
        MySqlCommand command = new MySqlCommand(query, conn);
        command.Parameters.AddWithValue("@id", id);
        conn.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Student Deleted Successfully!!!");
        }else {
            Console.WriteLine("Not Deleted!!!");
        }
        conn.Close();
        }
    }
