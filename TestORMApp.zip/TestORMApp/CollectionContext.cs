namespace DAL;
using BOL;
using Microsoft.EntityFrameworkCore;
public class CollectionContext : DbContext
{
    public DbSet<Store> storess { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        string conn = @"server=192.168.10.150;port=3306;user=dac31;password=welcome;database=dac31";
        optionsBuilder.UseMySQL(conn);
        //base.OnConfiguring(optionsBuilder);
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Store>(entity =>
        {
            entity.HasKey(e => e.id);
            entity.Property(e => e.clothes);
            entity.Property(e => e.rate);
        });
        modelBuilder.Entity<Store>().ToTable("store");
    }
}