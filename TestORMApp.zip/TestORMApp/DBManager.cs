
using BOL;

namespace DAL;
public class DBManager : IDBManager
{
    public void delete(int id)
    {
        throw new NotImplementedException();
    }

    public List<Store> GetAll()
    {
        //Here we r doing Deterministic Finalization using "Using()"
        using (var context = new CollectionContext())
        {
            //LINQ
            var stores = from store in context.storess select store;
            return stores.ToList<Store>();
        }
    }

    public void insert(Store s)
    {
        using (var context = new CollectionContext())
        {
            context.storess.Add(s);
            context.SaveChanges();
        }
    }

    public void update(Store s)
    {
        using (var context = new CollectionContext())
        {
            int id = s.id;

            Store s1 = context.storess.Find(id);
            s1.clothes = s.clothes;
            s1.rate = s.rate;
            context.SaveChanges();
        }
    }
}