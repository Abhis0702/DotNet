using BOL;

namespace DAL;
public interface IDBManager
{
    List<Store> GetAll();
    void insert(Store s);
    void update(Store s);
    void delete(int id);
}