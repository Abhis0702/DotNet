﻿using System;
using System.Collections.Generic;
using BOL;
using DAL;
Console.WriteLine("Welcome to Zudio Store");

IDBManager dbm = new DBManager();

bool status = true;

while (status)
{
    Console.WriteLine("Choose Option : ");
    Console.WriteLine("1.Display Clothes : ");
    Console.WriteLine("2.Add Clothes : ");
    Console.WriteLine("3.Update Clothes : ");
    Console.WriteLine("4.Delete Clothes : ");
    Console.WriteLine("5.Delete Clothes By Id : ");

    switch (Console.ReadLine())
    {
        case "1":
            List<Store> plist = dbm.GetAll();
            foreach (var store in plist)
            {
                Console.WriteLine("Id : " + store.id + ", Clothes : " + store.clothes + ", Rate : " + store.rate);
            }
            break;
        case "2":
            var s = new Store();
            Console.WriteLine("Enter Id :");
            s.id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Clothes :");
            s.clothes = Console.ReadLine();
            Console.WriteLine("Enter Rate :");
            s.rate = Convert.ToInt32(Console.ReadLine());
            dbm.insert(s);
            break;
        case "3":
             s = new Store();
            Console.WriteLine("Enter Id :");
            s.id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Clothes :");
            s.clothes = Console.ReadLine();
            Console.WriteLine("Enter Rate :");
            s.rate = Convert.ToInt32(Console.ReadLine());
            dbm.update(s);
            break;
        case "4":
            break;
        case "5":
            status = false;
            break;
    }
}


