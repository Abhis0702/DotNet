namespace BOL;
public class Store
{

    public int id { get; set; }
    public string clothes { get; set; }
    public int rate { get; set; }
}