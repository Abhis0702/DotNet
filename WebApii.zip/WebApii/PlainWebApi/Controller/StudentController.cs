using Microsoft.AspNetCore.Mvc;
using BOL;
using BLL;
namespace ReactWithWebAPIApp.Controllers;

[ApiController]
[Route("[controller]")]
public class StudentController : ControllerBase
{ 
    private readonly ILogger<StudentController> _logger;
    public StudentController(ILogger<StudentController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IEnumerable<Student> Get()
    {
        List<Student> students=StudentResource.getAllStudent();
        return  students.ToArray();
    }
    [HttpGet("{id}")]
    public Student GetById(int id)
    {
        Student s = StudentResource.GetStudent(id);
        return s;
    }
}